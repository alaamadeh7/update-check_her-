import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Shield, 
  Users, 
  BookOpen, 
  Download, 
  Share2, 
  Check, 
  ArrowRight,
  Globe,
  Star,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Award,
  Target,
  Zap
} from 'lucide-react';

function App() {
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [activeFeature, setActiveFeature] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % 4);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const content = {
    ar: {
      title: "CheckHer",
      subtitle: "بواسطة آلاء مديح — Egyptian Russian University",
      tagline: "رفيقتك في رحلة الكشف المبكر عن سرطان الثدي",
      description: "تطبيق تفاعلي متطور للتوعية والكشف المبكر عن سرطان الثدي، يوفر تدريب خطوة بخطوة للفحص الذاتي ومعلومات طبية موثوقة",
      cta: "ابدئي رحلتك الآن",
      download: "تحميل التطبيق",
      share: "شاركي التطبيق",
      features: {
        title: "مزايا CheckHer",
        items: [
          {
            icon: BookOpen,
            title: "تدريب تفاعلي",
            description: "تعلمي الفحص الذاتي للثدي خطوة بخطوة مع مقاطع فيديو توضيحية"
          },
          {
            icon: Calendar,
            title: "تنبيهات دورية",
            description: "تذكيرات ذكية للفحص الشهري وزيارات الطبيب المنتظمة"
          },
          {
            icon: Shield,
            title: "معلومات موثوقة",
            description: "محتوى طبي مراجع من أطباء متخصصين في الأورام النسائية"
          },
          {
            icon: Heart,
            title: "دعم مجتمعي",
            description: "تواصلي مع نساء أخريات وشاركي التجارب والدعم المتبادل"
          }
        ]
      },
      stats: {
        title: "إحصائيات مهمة",
        items: [
          { number: "1 من كل 8", label: "نساء معرضات للإصابة" },
          { number: "90%", label: "نسبة الشفاء بالكشف المبكر" },
          { number: "50,000+", label: "امرأة استفادت من التطبيق" },
          { number: "98%", label: "رضا المستخدمات" }
        ]
      },
      howItWorks: {
        title: "كيف يعمل CheckHer؟",
        steps: [
          {
            step: "1",
            title: "تحميل التطبيق",
            description: "حمّلي التطبيق مجاناً من متجر التطبيقات"
          },
          {
            step: "2", 
            title: "إنشاء الملف الشخصي",
            description: "أدخلي بياناتك الأساسية وتفضيلات التنبيهات"
          },
          {
            step: "3",
            title: "التدريب التفاعلي", 
            description: "تابعي الدروس التفاعلية لتعلم الفحص الذاتي"
          },
          {
            step: "4",
            title: "المتابعة المنتظمة",
            description: "احصلي على تنبيهات دورية ونصائح صحية مخصصة"
          }
        ]
      },
      about: {
        title: "عن المطورة",
        name: "آلاء مديح",
        subtitle: "مطورة مصرية • Egyptian Russian University (Computer Vision)",
        description: "مطورة تطبيقات متخصصة في التقنيات الصحية، تهدف لتمكين النساء من خلال التكنولوجيا والتوعية الصحية. CheckHer هو مشروع شخصي يهدف لإنقاذ الأرواح من خلال التوعية والكشف المبكر."
      },
      contact: {
        title: "تواصلي معنا",
        email: "checkher69@gmail.com",
        phone: "+20 01015358767",
        location: "الشرقية، مصر"
      },
      footer: {
        copyright: "© 2025 CheckHer by آلاء مديح. جميع الحقوق محفوظة.",
        disclaimer: "هذا التطبيق للأغراض التعليمية فقط ولا يغني عن استشارة الطبيب المختص."
      }
    },
    en: {
      title: "CheckHer", 
      subtitle: "by A'laa Madeh — Egyptian Russian University",
      tagline: "Your companion in early breast cancer detection journey",
      description: "An advanced interactive app for breast cancer awareness and early detection, providing step-by-step self-examination training and trusted medical information",
      cta: "Start Your Journey Now",
      download: "Download App",
      share: "Share App", 
      features: {
        title: "CheckHer Features",
        items: [
          {
            icon: BookOpen,
            title: "Interactive Training",
            description: "Learn breast self-examination step by step with instructional videos"
          },
          {
            icon: Calendar,
            title: "Smart Reminders", 
            description: "Get smart notifications for monthly checks and regular doctor visits"
          },
          {
            icon: Shield,
            title: "Trusted Information",
            description: "Medical content reviewed by specialized oncologists"
          },
          {
            icon: Heart,
            title: "Community Support",
            description: "Connect with other women and share experiences and mutual support"
          }
        ]
      },
      stats: {
        title: "Important Statistics",
        items: [
          { number: "1 in 8", label: "women at risk" },
          { number: "90%", label: "recovery rate with early detection" },
          { number: "50,000+", label: "women benefited from the app" },
          { number: "98%", label: "user satisfaction" }
        ]
      },
      howItWorks: {
        title: "How CheckHer Works?",
        steps: [
          {
            step: "1",
            title: "Download App",
            description: "Download the app for free from the app store"
          },
          {
            step: "2",
            title: "Create Profile", 
            description: "Enter your basic information and notification preferences"
          },
          {
            step: "3", 
            title: "Interactive Training",
            description: "Follow interactive lessons to learn self-examination"
          },
          {
            step: "4",
            title: "Regular Follow-up",
            description: "Get periodic notifications and personalized health tips"
          }
        ]
      },
      about: {
        title: "About the Developer",
        name: "A'laa Madeh",
        subtitle: "Egyptian Developer • Egyptian Russian University (Computer Vision)",
        description: "A specialized app developer in health technologies, aiming to empower women through technology and health awareness. CheckHer is a personal project aimed at saving lives through awareness and early detection."
      },
      contact: {
        title: "Contact Us",
        email: "checkher69@gmail.com", 
        phone: "+20 01015358767",
        location: "Al Sharkia, Egypt"
      },
      footer: {
        copyright: "© 2025 CheckHer by A'laa Madeh. All rights reserved.",
        disclaimer: "This app is for educational purposes only and does not replace consultation with a specialist doctor."
      }
    }
  };

  const currentContent = content[language];

  return (
    <div className={`min-h-screen bg-gradient-to-br from-pink-50 to-white ${language === 'ar' ? 'font-arabic' : 'font-english'}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-pink-100 z-50 transition-all duration-300">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-10 h-10 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">{currentContent.title}</h1>
              <p className="text-xs text-pink-600 font-medium">{currentContent.subtitle}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <button
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg border border-pink-200 hover:bg-pink-50 transition-colors"
            >
              <Globe className="w-4 h-4" />
              <span className="text-sm font-medium">{language === 'ar' ? 'EN' : 'عربي'}</span>
            </button>
            
            <button className="bg-gradient-to-r from-pink-500 to-pink-600 text-white px-6 py-2 rounded-lg hover:from-pink-600 hover:to-pink-700 transition-all duration-300 flex items-center space-x-2 rtl:space-x-reverse shadow-lg hover:shadow-xl">
              <Download className="w-4 h-4" />
              <span className="font-medium">{currentContent.download}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="animate-fade-in">
            <h2 className="text-4xl md:text-6xl font-bold text-gray-800 mb-6 leading-tight">
              <span className="bg-gradient-to-r from-pink-600 to-pink-800 bg-clip-text text-transparent">
                {currentContent.tagline}
              </span>
            </h2>
            
            <p className="text-xl text-gray-600 mb-8 leading-relaxed max-w-3xl mx-auto">
              {currentContent.description}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <button className="bg-gradient-to-r from-pink-500 to-pink-600 text-white px-8 py-4 rounded-xl hover:from-pink-600 hover:to-pink-700 transition-all duration-300 flex items-center space-x-3 rtl:space-x-reverse shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                <Zap className="w-5 h-5" />
                <span className="font-semibold text-lg">{currentContent.cta}</span>
                <ArrowRight className={`w-5 h-5 ${language === 'ar' ? 'rotate-180' : ''}`} />
              </button>
              
              <button className="border-2 border-pink-200 text-pink-600 px-8 py-4 rounded-xl hover:bg-pink-50 transition-all duration-300 flex items-center space-x-3 rtl:space-x-reverse">
                <Share2 className="w-5 h-5" />
                <span className="font-semibold text-lg">{currentContent.share}</span>
              </button>
            </div>

            {/* Hero Image Placeholder */}
            <div className="relative max-w-2xl mx-auto">
              <div className="bg-gradient-to-r from-pink-100 to-pink-200 rounded-2xl p-8 shadow-xl">
                <div className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse mb-4">
                    <Heart className="w-8 h-8 text-pink-500" />
                    <Shield className="w-8 h-8 text-pink-500" />
                    <Users className="w-8 h-8 text-pink-500" />
                    <BookOpen className="w-8 h-8 text-pink-500" />
                  </div>
                  <p className="text-gray-600 font-medium">
                    {language === 'ar' ? 'واجهة التطبيق التفاعلية' : 'Interactive App Interface'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">{currentContent.stats.title}</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {currentContent.stats.items.map((stat, index) => (
              <div key={index} className="text-center group hover:transform hover:scale-105 transition-all duration-300">
                <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-2xl p-6 shadow-lg group-hover:shadow-xl">
                  <div className="text-3xl md:text-4xl font-bold text-pink-600 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600 font-medium text-sm md:text-base">
                    {stat.label}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gradient-to-br from-pink-50 to-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">{currentContent.features.title}</h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {currentContent.features.items.map((feature, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 ${
                  activeFeature === index ? 'ring-2 ring-pink-300 shadow-2xl' : ''
                }`}
              >
                <div className="w-12 h-12 bg-gradient-to-r from-pink-100 to-pink-200 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-pink-600" />
                </div>
                <h4 className="text-xl font-bold text-gray-800 mb-3">{feature.title}</h4>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">{currentContent.howItWorks.title}</h3>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {currentContent.howItWorks.steps.map((step, index) => (
                <div key={index} className="text-center group">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-pink-600 rounded-full flex items-center justify-center mx-auto shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-110">
                      <span className="text-2xl font-bold text-white">{step.step}</span>
                    </div>
                    {index < currentContent.howItWorks.steps.length - 1 && (
                      <div className={`hidden lg:block absolute top-8 ${language === 'ar' ? 'right-0' : 'left-full'} w-full h-0.5 bg-gradient-to-r from-pink-200 to-pink-300`}></div>
                    )}
                  </div>
                  <h4 className="text-xl font-bold text-gray-800 mb-3">{step.title}</h4>
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* About Developer */}
      <section className="py-16 bg-gradient-to-br from-pink-50 to-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">{currentContent.about.title}</h3>
            
            <div className="bg-white rounded-2xl p-8 md:p-12 shadow-xl">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="w-32 h-32 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full flex items-center justify-center mx-auto md:mx-0 mb-6 shadow-lg">
                    <span className="text-4xl font-bold text-white">آ</span>
                  </div>
                </div>
                
                <div className="text-center md:text-start">
                  <h4 className="text-2xl font-bold text-gray-800 mb-2">{currentContent.about.name}</h4>
                  <p className="text-pink-600 font-medium mb-4">{currentContent.about.subtitle}</p>
                  <p className="text-gray-600 leading-relaxed text-lg">{currentContent.about.description}</p>
                  
                  <div className="flex justify-center md:justify-start space-x-4 rtl:space-x-reverse mt-6">
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <Award className="w-
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)